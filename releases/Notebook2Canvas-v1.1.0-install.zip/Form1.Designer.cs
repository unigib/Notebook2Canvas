﻿namespace Notebook2Canvas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rjButton3 = new Notebook2Canvas.RJButton();
            this.rjButton2 = new Notebook2Canvas.RJButton();
            this.rjButtonExport = new Notebook2Canvas.RJButton();
            this.rjButton1 = new Notebook2Canvas.RJButton();
            this.rjButtonPrefs = new Notebook2Canvas.RJButton();
            // comboBox1 removed - not used anymore
            this.labelConverter = new System.Windows.Forms.Label();
            this.textBoxConverterPath = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(816, 321);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 33);
            this.button1.TabIndex = 1;
            this.button1.Text = "Quit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 115);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(441, 202);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(287, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(574, 20);
            this.textBox1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(194, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "JSON Export File";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(482, 113);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(417, 202);
            this.richTextBox2.TabIndex = 6;
            this.richTextBox2.Text = "";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(287, 47);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(574, 20);
            this.textBox2.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(194, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "MD File Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Notebook LM  Export JSON";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(488, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "QTI Markdown";
            // 
            // rjButton3
            // 
            this.rjButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButton3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButton3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton3.BorderRadius = 5;
            this.rjButton3.BorderSize = 1;
            this.rjButton3.FlatAppearance.BorderSize = 0;
            this.rjButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton3.ForeColor = System.Drawing.Color.White;
            this.rjButton3.Location = new System.Drawing.Point(131, 321);
            this.rjButton3.Name = "rjButton3";
            this.rjButton3.Size = new System.Drawing.Size(150, 33);
            this.rjButton3.TabIndex = 8;
            this.rjButton3.Text = "JSON to MD";
            this.rjButton3.TextColor = System.Drawing.Color.White;
            this.rjButton3.UseVisualStyleBackColor = false;
            this.rjButton3.Click += new System.EventHandler(this.rjButton3_Click);
            // 
            // rjButton2
            // 
            this.rjButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButton2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButton2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton2.BorderRadius = 5;
            this.rjButton2.BorderSize = 1;
            this.rjButton2.FlatAppearance.BorderSize = 0;
            this.rjButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton2.ForeColor = System.Drawing.Color.White;
            this.rjButton2.Location = new System.Drawing.Point(639, 321);
            this.rjButton2.Name = "rjButton2";
            this.rjButton2.Size = new System.Drawing.Size(131, 33);
            this.rjButton2.TabIndex = 7;
            this.rjButton2.Text = "Save MD";
            this.rjButton2.TextColor = System.Drawing.Color.White;
            this.rjButton2.UseVisualStyleBackColor = false;
            this.rjButton2.Click += new System.EventHandler(this.rjButton2_Click);
            // 
            // rjButtonExport
            // 
            this.rjButtonExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButtonExport.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButtonExport.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButtonExport.BorderRadius = 5;
            this.rjButtonExport.BorderSize = 1;
            this.rjButtonExport.FlatAppearance.BorderSize = 0;
            this.rjButtonExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButtonExport.ForeColor = System.Drawing.Color.White;
            this.rjButtonExport.Location = new System.Drawing.Point(482, 321);
            this.rjButtonExport.Name = "rjButtonExport";
            this.rjButtonExport.Size = new System.Drawing.Size(131, 33);
            this.rjButtonExport.TabIndex = 14;
            this.rjButtonExport.Text = "Export → QTI";
            this.rjButtonExport.TextColor = System.Drawing.Color.White;
            this.rjButtonExport.UseVisualStyleBackColor = false;
            this.rjButtonExport.Click += new System.EventHandler(this.rjButtonExportQti_Click);
            // 
            // rjButtonPrefs
            // 
            this.rjButtonPrefs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButtonPrefs.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(0)))), ((int)(((byte)(12)))));
            this.rjButtonPrefs.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButtonPrefs.BorderRadius = 5;
            this.rjButtonPrefs.BorderSize = 1;
            this.rjButtonPrefs.FlatAppearance.BorderSize = 0;
            this.rjButtonPrefs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButtonPrefs.ForeColor = System.Drawing.Color.White;
            this.rjButtonPrefs.Location = new System.Drawing.Point(x: 339, y: 321);
            this.rjButtonPrefs.Name = "rjButtonPrefs";
            this.rjButtonPrefs.Size = new System.Drawing.Size(131, 33);
            this.rjButtonPrefs.TabIndex = 15;
            this.rjButtonPrefs.Text = "Preferences";
            this.rjButtonPrefs.TextColor = System.Drawing.Color.White;
            this.rjButtonPrefs.UseVisualStyleBackColor = false;
            this.rjButtonPrefs.Click += new System.EventHandler(this.rjButtonPrefs_Click);
            // 
            // rjButton1
            // 
            this.rjButton1.BackColor = System.Drawing.Color.Crimson;
            this.rjButton1.BackgroundColor = System.Drawing.Color.Crimson;
            this.rjButton1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton1.BorderRadius = 5;
            this.rjButton1.BorderSize = 1;
            this.rjButton1.FlatAppearance.BorderSize = 0;
            this.rjButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton1.ForeColor = System.Drawing.Color.White;
            this.rjButton1.Location = new System.Drawing.Point(21, 24);
            this.rjButton1.Name = "rjButton1";
            this.rjButton1.Size = new System.Drawing.Size(150, 40);
            this.rjButton1.TabIndex = 0;
            this.rjButton1.Text = "Load NotebookLM JSON";
            this.rjButton1.TextColor = System.Drawing.Color.White;
            this.rjButton1.UseVisualStyleBackColor = false;
            this.rjButton1.Click += new System.EventHandler(this.rjButton1_Click);
            // 
            // comboBox1
            // 
            // comboBox1 removed - not used anymore

            // 
            // labelConverter
            // 
            this.labelConverter.AutoSize = true;
            this.labelConverter.Location = new System.Drawing.Point(194, 78);
            this.labelConverter.Name = "labelConverter";
            this.labelConverter.Size = new System.Drawing.Size(54, 13);
            this.labelConverter.TabIndex = 16;
            this.labelConverter.Text = "Converter:";
            // 
            // textBoxConverterPath
            // 
            this.textBoxConverterPath.Location = new System.Drawing.Point(287, 75);
            this.textBoxConverterPath.Name = "textBoxConverterPath";
            this.textBoxConverterPath.ReadOnly = true;
            this.textBoxConverterPath.Size = new System.Drawing.Size(574, 20);
            this.textBoxConverterPath.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(988, 431);
            this.Controls.Add(this.rjButtonExport);
            this.Controls.Add(this.rjButtonPrefs);
            this.Controls.Add(this.labelConverter);
            this.Controls.Add(this.textBoxConverterPath);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rjButton2);
            this.Controls.Add(this.rjButton3);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.rjButton1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Notebook2Canvas";
            this.ResumeLayout(false);
            this.PerformLayout();
            this.textBoxConverterPath.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(988, 431);
            // comboBox1 removed - not used anymore
            this.Controls.Add(this.rjButtonExport);
            this.Controls.Add(this.rjButtonPrefs);
            this.Controls.Add(this.labelConverter);
            this.Controls.Add(this.textBoxConverterPath);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.rjButton3);
            this.Controls.Add(this.rjButton2);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.rjButton1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "UniGib Google Notebook to Canvas QTI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RJButton rjButton1;
        private RJButton rjButtonExport;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private RJButton rjButton2;
        private RJButton rjButton3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        // comboBox1 removed - not used anymore
        private RJButton rjButtonPrefs;
        private System.Windows.Forms.Label labelConverter;
        private System.Windows.Forms.TextBox textBoxConverterPath;
    }
}

